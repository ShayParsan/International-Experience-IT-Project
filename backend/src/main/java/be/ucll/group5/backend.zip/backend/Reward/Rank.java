package be.ucll.group5.backend.Reward;

public enum Rank {
    BRONZE, SILVER, GOLD, PLATINUM
}