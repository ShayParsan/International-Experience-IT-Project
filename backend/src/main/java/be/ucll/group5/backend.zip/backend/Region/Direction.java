package be.ucll.group5.backend.Region;

public enum Direction {
    NORTH, SOUTH, EAST, WEST, NORTHEAST, SOUTHEAST, NORTHWEST, SOUTHWEST
}
